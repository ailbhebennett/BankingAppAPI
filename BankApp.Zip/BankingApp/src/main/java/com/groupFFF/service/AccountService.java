
package com.groupFFF.service;

import Datastore.Datastore;
import com.groupFFF.models.Account;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * FFF
 */
public class AccountService {

    Datastore a = new Datastore();
    private List<Account> account = a.getAccountService();
    
    
    public List<Account> getAllAccounts() {
        return account;
    }
    
    public Account getAccount(int id){
        return account.get(id-1);
    }
    
    public Account createAccount(Account c){
        a.setAccountId(account.size() + 1);
        account.add(c);
        System.out.println("Account Created : " + 
                  String.valueOf(c.getAccountId()));
        return c;
        }
    
    public Account CurrentBal(int currentBal){
        return CurrentBal(currentBal);
    }
    
    public int setCurrentBal(int currentBal){
        return currentBal;      
    }
    
    public int Lodgement(int currentBal, int lodgeAmount){
        if(currentBal <= lodgeAmount){
            currentBal= currentBal + lodgeAmount;
        }
        return currentBal;
    }
    
    public int Withdraw(int currentBal, int withdrawAmount){
        if(currentBal >= withdrawAmount){
            currentBal = currentBal - withdrawAmount;
        }
        return currentBal;
    }
        
}

   
