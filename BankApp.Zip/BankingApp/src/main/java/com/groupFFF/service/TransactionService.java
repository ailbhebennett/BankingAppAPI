package com.groupFFF.service;

import Datastore.Datastore;
import com.groupFFF.models.Transaction;
import java.util.List;

/**
 *
 * FFF
 */
public class TransactionService {
    Datastore d = new Datastore();
    private List<Transaction> transaction = d.getTransaction();
    
    public List<Transaction> getAllTransactions(){
        return transaction;
    }
    
    public Transaction getAccount(int id){
        return transaction.get(id-1);
    }
    
    public Transaction createCreditTransaction(Transaction ct){
        ct.setId(transaction.size() + 1);
        ct.setCredit(true);
        transaction.add(ct);
        System.out.println("Transaction Id Created credit : " + String.valueOf(ct.getId()));
        return ct;
    }
    
    public Transaction createDebitTransaction(Transaction dt){
        dt.setId(transaction.size() + 1);
        dt.setDebit(true);
        transaction.add(dt);
        System.out.println("Transaction Id Created debit : " + String.valueOf(dt.getId()));
        return dt;
    }
}
