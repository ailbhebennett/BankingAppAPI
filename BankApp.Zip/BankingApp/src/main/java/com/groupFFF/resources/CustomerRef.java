
package com.groupFFF.resources;

import com.groupFFF.models.Customer;
import com.groupFFF.service.CustomerService;
import com.groupFFF.models.Account;
import com.groupFFF.models.Transaction;
import com.groupFFF.service.AccountService;
import Datastore.Datastore;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * FFF
 */

@Path("/customers")

public class CustomerRef {
    private CustomerService CustomerService = new CustomerService();
    private AccountService AccountService = new AccountService();
    
    //get all customers
     @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Customer> getCustomers() {
        //Return a list of all customers
        return CustomerService.getAllCustomers();
    }//End get al customers
    
     //create a customer
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Customer postCustomer(Customer c) {
        //Creates a new customer and returns it
        return CustomerService.createCustomer(c);
    } //End create a customer
  
     //Get a specific customer
    @GET
    @Path("/{customerID}")
    @Produces(MediaType.APPLICATION_JSON)
    public Customer getSpecificCustomer(@PathParam("customerID") int c_id ) {
        //gets customer for CustomerServices and returns it
	return CustomerService.getCustomer(c_id);
    }//End get a customer
    
    //Get account for specific customer
    @GET
    @Path("/{customerID}/accounts/{accountID}")
    @Produces(MediaType.APPLICATION_JSON)
    public Account getCustomerAccount(@PathParam("customerID") int c_id, @PathParam("accountID") int a_id ) {
        //Get specific customer from customers using id
        Customer cust = CustomerService.getCustomer(c_id);
        //Get a list of the accounts on that customer
        List<Account> accounts = cust.getAccounts();
        //Return the specific account from the array of accounts
	return accounts.get(a_id-1);
    }
    
    //Add a new account to a specific customer
    @POST
    @Path("/{customerID}/accounts")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Account addCustomerAccount(@PathParam("customerId") int c_id, Account account) {
        //Get the customer you will be adding the account to
        Customer cust = CustomerService.getCustomer(c_id);
        //Get a list of the accounts for that customer
        List<Account> accounts = cust.getAccounts();
        //Set the id of the account
        account.setAccountId(accounts.size()+1);
        //Add the new account to the list of accounts
        accounts.add(account);
        //Set the list of accounts within the customer to the updated list
        cust.setAccounts(accounts);
        //Update the customer entry within customersService
        CustomerService.setCustomer(c_id, cust);
        //Return the newly create account
	return CustomerService.getCustomer(c_id).getAccounts().get(accounts.size()-1);
    }//End add a new account
   
    
    //Transfer balance (currentBal) from account (accountId) to account2 (account2Id)
    @PATCH
    @Path("/{customerID}/accounts/{accountID}/transaction/{id}/accounts2/{accounts2Id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Transaction setCustomerBal(@PathParam("accountId") int c_id, @PathParam("accountId") int a_id , @PathParam("customerBal") int cb_id, @PathParam("accounts2ID") int a2_id) {
        Customer cust = CustomerService.getCustomer(c_id);
        //Get list of the accounts and specific account
        List<Account> accounts = cust.getAccounts();
        Account account = accounts.get(a_id-1);
        //Get a list of transactions in the customers account.
        List<Transaction> transactions = account.getTransactions();
	Transaction transferB = transactions.get(cb_id-1);
        transactions.remove(cb_id-1);
        //For loop to update the Id of all transactions 
        for(int i=0; i<transactions.size(); i++){
            Transaction temp1 = transactions.get(i);
            temp1.setId(i+1);
            transactions.set(i, temp1);
        }//End for loop
        //Set Transactions
        account.setTransactions(transactions);
        accounts.set(a_id-1, account);
      
        account = accounts.get(a2_id-1);
        transactions = account.getTransactions();
        transferB.setId(transactions.size()+1);
        transactions.add(transferB);
        account.setTransactions(transactions);
        accounts.set(a2_id-1, account);
        cust.setAccounts(accounts);
        CustomerService.setCustomer(c_id, cust);
        return transferB;
    }//End transaction 
    
    //Lodgement 
    @POST
    @Path("/{customerId}/accounts/{accountsId}/{lodgeAmount}")
    @Produces(MediaType.APPLICATION_JSON)
    public int Lodgement(@PathParam("customerId") int c_id, @PathParam("lodgeAmount") int lodgeAmount, @PathParam("accountId") int a_id){
        CustomerService.getCustomer(c_id).getAccount(a_id).setCurrentBal(CustomerService.getCustomer(c_id).getAccount(a_id).getCurrentBal()+lodgeAmount);
        return CustomerService.getCustomer(c_id).getAccount(a_id).getCurrentBal();
    }
    
    //WithDrawl
    @POST
    @Path("{customerId}/accounts/{accountsId}/{withdrawAmount}")
    @Produces(MediaType.APPLICATION_JSON)
    public int Withdraw(@PathParam("customerId")int c_id, @PathParam("withdrawAmount") int withdraw, @PathParam("accountId") int a_id){
    CustomerService.getCustomer(c_id).getAccount(a_id).setCurrentBal(CustomerService.getCustomer(c_id).getAccount(a_id).getCurrentBal()-withdraw);
    return CustomerService.getCustomer(c_id).getAccount(a_id).getCurrentBal();
    }
    
    
    //Balance amount in customer account 
    @GET
    @Path("{customerId}/accounts/{accountId}/{currentBal}")
    @Produces(MediaType.APPLICATION_JSON)
    public int getCustomerAccountBalance(@PathParam("currentBal") int currentBal, @PathParam ("accountId") int a_id, @PathParam ("customerId") int c_id) {
        Customer cust = CustomerService.getCustomer(c_id);
        if(cust != null) {
             Account accounts = AccountService.getAccount(a_id);
             
             if(accounts !=null){
                return accounts.getCurrentBal();
             }  
        }
        return 0;   
    }
}
