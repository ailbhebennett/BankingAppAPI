
package Datastore;

import com.groupFFF.models.Account;
import com.groupFFF.models.Customer;
import com.groupFFF.models.Transaction;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * groupFFF
 */
public class Datastore {
    public static List<Account> accountDs = new ArrayList<>();
    public static List<Account> accountDs2 = new ArrayList<>();
    public static List<Account> accountDs3 = new ArrayList<>();
    public static List<Customer> customerDs = new ArrayList<>();
    public static List<Transaction> transactionDs = new ArrayList<>();
    public static List<Transaction> transactionDs2 = new ArrayList<>();
    public static List<Transaction> transactionDs3 = new ArrayList<>();
    
    public static boolean init = true;
    
    public Datastore(){
        if(init){
            Transaction t1 = new Transaction(1, true, false, "20/03/2021", "Credit", 2000);
            transactionDs.add(t1);
            t1 = new Transaction(1, true, false, "20/04/2021", "Credit", 2001);
            transactionDs2.add(t1);
            t1 = new Transaction(1, true, false, "20/05/2021", "Credit", 2005);
            transactionDs3.add(t1);
            
            Account accountDs1 = new Account (1, 209, 29000, transactionDs);
            accountDs.add(accountDs1);
            accountDs1 = new Account(1, 203, 3030, transactionDs2);
            accountDs2.add(accountDs1);
            
            Customer c1 = new Customer (1, "george", "5 ontheroad street", "email@email.com", accountDs);
            customerDs.add(c1);
        }
        
    }  
    
    public static List<Account> getAccountsDs() {
    return accountDs;
    }
    
    public static List<Customer> getCustomersDs() {
        return customerDs;
    }

    public static List<Transaction> getTransactionDs() {
        return transactionDs;
    }
}




